const https = require('https');

const payload = {
    id: "TNB000001",
    type: 380001,
    data: {
        dts: 1650946232574,
        seq: 1,
        status: 1,
        fwVersion: "1.0.1",
        pinetime: {
            accel_x: 100,
            accel_y: 200,
            accel_z: 300,
            hr: 80,
            batt: 100,
            rssiBLE: -80
        }
    }
}

payload.data.pinetime.hr = 100;

data = JSON.stringify(payload)

const options = {
    hostname: 'api.aidery.io',
    path: '/data-log',
    method: 'POST',
    headers: {
        'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYyOGNhZWRkMTgxODU5MDAxMjg4MjIzZCIsInJvbGUiOjUwLCJpYXQiOjE2NTMzODY5NzN9.6quw2KM9YWYshU1i5dJa3K-UbUJAkjZj6kIWdUv7uRY`,
        'Content-Type': 'application/json',
        'Content-Length': data.length
    }
};

setInterval(() => {
    const req = https.request(options, (res) => {
        let data = '';

        console.log('Status Code:', res.statusCode);

        res.on('data', (chunk) => {
            data += chunk;
        });

        res.on('end', () => {
            console.log('Body: ', JSON.parse(data));
        });

    }).on("error", (err) => {
        console.log("Error: ", err.message);
    });

    req.write(data);
    req.end();
}, 5000);