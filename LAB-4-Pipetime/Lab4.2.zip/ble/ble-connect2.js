var noble = require("noble");

/* BLE Function */
//on bluetooth adaptor state change
noble.on("stateChange", async function (state) {
  if (state === "poweredOn") {
    console.log("Bluetooth Adaptor is On");
    startScan();
  } else {
    console.log("other state >> ", state);
  }
});

//on ble start scan
noble.on("scanStart", function () {
  console.log("on -> scanStart");
});

// on ble stop scan
noble.on("scanStop", function () {
  console.log("on -> scanStop");
});

noble.on("discover", async function (peripheral) {
  //   peripheral.disconnect((error) => {
  //     console.log("Disconnect or cancel pending connection");
  //   });
  const PINETIME_MAC_ADDRESS = "e0:e0:5f:ca:14:9f";
  /* Battery */
  const BATTERY_SERVICE_UUID = "180f";
  const BATTERY_CHARACTERISTIC_UUID = "2a19";
  /* Heart Rate */
  const HEARTRATE_SERVICE_UUID = "180d";
  const HEARTRATE_CHARACTERISTIC_UUID = "2a37";

  let connectDeviceData = [];
  //   console.log(peripheral.address);
  if (peripheral.address === PINETIME_MAC_ADDRESS) {
    console.log("Found PINETIME");
    stopScan();
    peripheral.connect(async function (error) {
      console.log("connected !");
      const serviceUUIDs = [BATTERY_SERVICE_UUID, HEARTRATE_SERVICE_UUID];
      const characteristicUUIDs = [
        BATTERY_CHARACTERISTIC_UUID,
        HEARTRATE_CHARACTERISTIC_UUID,
      ];

      /* delay to disconnect */
      // setTimeout(async function () {
      //   peripheral.disconnect(function (error) {
      //     console.log("Time Out -> Disconnected");
      //   });
      // }, 15 * 1000);

      peripheral.discoverSomeServicesAndCharacteristics(
        serviceUUIDs,
        characteristicUUIDs,
        // onServicesAndCharacteristicsDiscovered
        (error, services, characteristics) => {
          console.log("Discovered Service !");
          setInterval(() => {
            console.log("Read !");
            const BATTERY_CHARACTERISTIC = characteristics[0];
            BATTERY_CHARACTERISTIC.read((error, data) => {
              console.log("BATTERY Data : ", data);
              const batt = data[0] + "%";
              console.log("BATTERY >>> : ", batt);
            });

            const HEARTRATE_CHARACTERISTIC = characteristics[1];
            HEARTRATE_CHARACTERISTIC.read((error, data) => {
              console.log("HEARTRATE Data : ", data);
              const hr = data[1] + " BPM";
              console.log("hr >>> : ", hr);
              // peripheral.disconnect(function (error) {
              //   console.log("Disconnected");
              // });
            });
          }, 3000);
        }
      );
    });
  } else {
    // console.log("not found");
  }
});

// start scan function
function startScan() {
  console.log("on call start scan");
  var bleState = noble.state;
  if (bleState == "poweredOn") {
    noble.startScanning([], true);
  } else {
    noble.stopScanning();
  }
}

// stop scan function
function stopScan() {
  console.log("on call stop scan");
  var bleState = noble.state;
  if (bleState == "poweredOn") {
    noble.stopScanning();
  } else {
    noble.stopScanning();
  }
}

/* Utils Function */

// Functions Convert Byte to HexString
function toHexString(arr) {
  var str = "";
  for (var i = 0; i < arr.length; i++) {
    str += (arr[i] < 16 ? "0" : "") + arr[i].toString(16);
    str += ":";
  }
  return str;
}

function timeout(second) {
  //   console.log("on set time out");
  second = second * 1000;
  return new Promise((resolve) => setTimeout(resolve, second));
}
