var noble = require('noble');

//on bluetooth adaptor state change 
noble.on('stateChange', async function (state) {
    if (state === 'poweredOn') {
        console.log('Bluetooth Adaptor is On');
        startScan();
    } else {
        console.log('other state >> ', state)
    }
});


//on ble start scan
noble.on('scanStart', function () {
    console.log('on -> scanStart');
});

// on ble stop scan
noble.on('scanStop', function () {
    console.log('on -> scanStop');
});

noble.on('discover', async function (peripheral) {
    let connectDeviceData = []
    if (peripheral.address === 'e0:e0:5f:ca:14:9f') {
        let deviceData = []
        stopScan()
        peripheral.connect(async function (error) {
            console.log('connected to peripheral: ' + peripheral.uuid);

            // list all service
            peripheral.discoverServices(null, async function (error, services) {
                console.log('on list all service')
                for (var i in services) {
                    console.log('service uuid >> ', services[i].uuid);
                    deviceData.push({
                        service: { uuid: services[i].uuid },
                        characteristic: []
                    })
                    services[i].discoverCharacteristics(null, function (error, characteristics) {
                        for (var characteristic of characteristics) {
                            console.log('characteristics uuid >> ', characteristic.uuid);
                            console.log('characteristics uuid >> ', characteristic.properties);
                            deviceData[i].characteristic.push({
                                uuid: characteristic.uuid,
                                type: characteristic.properties
                            })
                        }
                        1
                    });
                    await timeout(1)
                }
            });
            await timeout(5)
            console.log('device data >> ', deviceData)
            peripheral.disconnect(function (error) {
                console.log('disconnected from peripheral: ' + peripheral.uuid);
            });
        });

    } else {
        console.log('not found')
    }
});

// Functions Convert Byte to HexString
function toHexString(arr) {
    var str = '';
    for (var i = 0; i < arr.length; i++) {
        str += ((arr[i] < 16) ? "0" : "") + arr[i].toString(16);
        str += ":";
    }
    return str;
}

// start scan function
function startScan() {
    console.log('on call start scan')
    var bleState = noble.state;
    if (bleState == 'poweredOn') {
        noble.startScanning([], true);
    } else {
        noble.stopScanning();

    }
}

// stop scan function
function stopScan() {
    console.log('on call stop scan')
    var bleState = noble.state;
    if (bleState == 'poweredOn') {
        noble.stopScanning();
    } else {
        noble.stopScanning();
    }
}

function timeout(second) {
    console.log('on set time out')
    second = second * 1000
    return new Promise(resolve => setTimeout(resolve, second));
}
